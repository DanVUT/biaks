package sk.tuke;

public class Helper {
    public static int calculateBits(byte[] message){
        return message.length * 8;
    }
}
